class Main {
  public static void main(String[] args) {
    Game master = new Game();
  }
}